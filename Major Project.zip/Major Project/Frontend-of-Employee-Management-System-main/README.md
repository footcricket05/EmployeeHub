# git-github-intro

## Git &amp; GitHub introduction repo 2021-22

### Name(Roll No) --- Github Username --- Batch --- E-mail<br/>

- Anubhav Dixit(B19ME008) --- anubhavdxt --- 2019 --- anubhavdxt46@gmail.com<br/>
- Koninika Tarafdar(B21ME012) --- Koninikax --- 2021 --- b21me012@nitm.ac.in<br/>
- Yash Raj Gupta(B21ME027) --- Yash-Raj-Gupta --- 2021 --- yrg28decscientist@gmail.com<br/>
- Ananya Manohar(B21CS003) --- Ananya-Manohar ---2021 --- ananyamanohar22@gmail.com<br/>
- Arkibud Broadwin Ryntathiang(B21ME001) --- arkibud --- 2021 --- b21me001@nitm.ac.in<br/>
- Utkarsh Kumar (B18EC033) --- utkarshkanswal --- 2018 --- utkarshkanswal@gmail.com<br/>
- Manish Kumar Dubey (B21EC021) ---dubeymanish4873 --- 2021 --- dubeymanish4873@gmail.com<br/>
- Nitesh Singh(B21CS025) --- NITESH-SINGH-SE ---2021 --- niteshsingh.se@gmail.com<br/>
- Akshat Jain(B20CS034) --- akshat2002aj ---2020 --akshat2002aj@gmail.com<br/>
- Kalpesh Vishwakarma(B20EC0003) --- KA1PE5H --- 2021 --- kalpeshvish7@gmail.com<br/> 
